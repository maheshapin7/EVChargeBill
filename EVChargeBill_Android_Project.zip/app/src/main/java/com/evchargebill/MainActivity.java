package com.evchargebill;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private EditText customer, phone, vehicle, kwh, rate, service, parking, gst;
    private TextView energyAmt, subtotal, gstAmt, total;
    private SharedPreferences prefs;
    private final NumberFormat inr = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("station", MODE_PRIVATE);
        buildUi();
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }

    private TextView tv(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp);
        t.setTextColor(0xFF102A43);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(4), dp(5), dp(4), dp(5));
        return t;
    }

    private EditText field(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextSize(16); e.setSingleLine(true);
        e.setInputType(type);
        e.setPadding(dp(14), dp(10), dp(14), dp(10));
        return e;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF4F7FA);

        TextView head = tv("⚡ EV CHARGE BILL", 23, true);
        head.setTextColor(0xFFFFFFFF); head.setBackgroundColor(0xFF0B1F33);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(18), dp(14), dp(18), dp(14));
        root.addView(head, new LinearLayout.LayoutParams(-1, dp(64)));

        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(10), dp(14), dp(20));

        TextView station = tv(prefs.getString("name","EV Charging Station"), 18, true);
        box.addView(station);

        Button settings = new Button(this);
        settings.setText("Station Settings");
        settings.setOnClickListener(v -> stationDialog(station));
        box.addView(settings);

        box.addView(tv("CUSTOMER & VEHICLE", 14, true));
        customer = field("Customer name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        phone = field("Phone (optional)", InputType.TYPE_CLASS_PHONE);
        vehicle = field("Vehicle number", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        box.addView(customer); box.addView(phone); box.addView(vehicle);

        box.addView(tv("CHARGING", 14, true));
        kwh = field("Energy (kWh)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        rate = field("Rate per kWh (₹)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        service = field("Service charge (₹)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        parking = field("Parking charge (₹)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        gst = field("GST %", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        rate.setText("15"); service.setText("0"); parking.setText("0"); gst.setText("18");
        box.addView(kwh); box.addView(rate); box.addView(service); box.addView(parking); box.addView(gst);

        Button calc = new Button(this); calc.setText("CALCULATE BILL");
        calc.setOnClickListener(v -> calculate());
        box.addView(calc);

        energyAmt = tv("Energy: ₹0.00", 16, false);
        subtotal = tv("Subtotal: ₹0.00", 16, false);
        gstAmt = tv("GST: ₹0.00", 16, false);
        total = tv("TOTAL: ₹0.00", 21, true);
        box.addView(energyAmt); box.addView(subtotal); box.addView(gstAmt); box.addView(total);

        Button pdf = new Button(this); pdf.setText("GENERATE PDF & SHARE");
        pdf.setOnClickListener(v -> generateAndShare());
        box.addView(pdf);

        Button clear = new Button(this); clear.setText("CLEAR");
        clear.setOnClickListener(v -> clearForm());
        box.addView(clear);

        scroll.addView(box);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private double val(EditText e) {
        try { return Double.parseDouble(e.getText().toString().trim()); }
        catch(Exception ex) { return 0; }
    }

    private String money(double x) { return inr.format(x); }

    private void calculate() {
        double e = val(kwh), r = val(rate), s = val(service), p = val(parking), g = val(gst);
        double energy = e*r, sub = energy+s+p, tax = sub*g/100.0, tot = sub+tax;
        energyAmt.setText("Energy: " + money(energy));
        subtotal.setText("Subtotal: " + money(sub));
        gstAmt.setText("GST (" + g + "%): " + money(tax));
        total.setText("TOTAL: " + money(tot));
    }

    private String invoiceNo() {
        long n = prefs.getLong("counter", 1000) + 1;
        prefs.edit().putLong("counter", n).apply();
        return "EV-" + new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()) + "-" + n;
    }

    private void generateAndShare() {
        calculate();
        double e=val(kwh), r=val(rate), s=val(service), p=val(parking), g=val(gst);
        double energy=e*r, sub=energy+s+p, tax=sub*g/100, tot=sub+tax;
        if (e <= 0 || r < 0) { Toast.makeText(this,"Enter valid energy and rate.",Toast.LENGTH_SHORT).show(); return; }

        String inv=invoiceNo();
        File dir=new File(getCacheDir(),"invoices"); dir.mkdirs();
        File pdf=new File(dir, inv+".pdf");

        PdfDocument doc=new PdfDocument();
        PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());
        Canvas c=page.getCanvas();
        Paint pnt=new Paint(Paint.ANTI_ALIAS_FLAG);
        pnt.setColor(0xFF102A43);
        pnt.setTypeface(Typeface.DEFAULT_BOLD);
        pnt.setTextSize(24);
        c.drawText(prefs.getString("name","EV Charging Station"),40,55,pnt);
        pnt.setTypeface(Typeface.DEFAULT); pnt.setTextSize(13);
        c.drawText("EV CHARGING INVOICE",40,82,pnt);
        c.drawText("Invoice: "+inv,390,55,pnt);
        c.drawText("Date: "+new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.US).format(new Date()),390,75,pnt);

        int y=125;
        pnt.setTextSize(14); pnt.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("Customer & Vehicle",40,y,pnt); y+=25;
        pnt.setTypeface(Typeface.DEFAULT);
        c.drawText("Customer: "+customer.getText(),40,y,pnt); y+=20;
        c.drawText("Phone: "+phone.getText(),40,y,pnt); y+=20;
        c.drawText("Vehicle: "+vehicle.getText(),40,y,pnt); y+=35;

        pnt.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Description",40,y,pnt); c.drawText("Amount",450,y,pnt); y+=25;
        pnt.setTypeface(Typeface.DEFAULT);
        row(c,pnt,"Charging: "+e+" kWh × "+money(r),energy,y); y+=25;
        row(c,pnt,"Service charge",s,y); y+=25;
        row(c,pnt,"Parking charge",p,y); y+=25;
        row(c,pnt,"Subtotal",sub,y); y+=25;
        row(c,pnt,"GST ("+g+"%)",tax,y); y+=35;
        pnt.setTypeface(Typeface.DEFAULT_BOLD); pnt.setTextSize(18);
        c.drawText("TOTAL",40,y,pnt); c.drawText(money(tot),430,y,pnt);

        y+=55; pnt.setTypeface(Typeface.DEFAULT); pnt.setTextSize(11);
        c.drawText("Generated offline by EV Charge Bill",40,y,pnt);
        c.drawText("This is a computer-generated invoice.",40,y+18,pnt);
        doc.finishPage(page);
        try {
            FileOutputStream out=new FileOutputStream(pdf); doc.writeTo(out); out.close(); doc.close();
            Uri uri= FileProvider.getUriForFile(this,getPackageName()+".fileprovider",pdf);
            Intent send=new Intent(Intent.ACTION_SEND); send.setType("application/pdf");
            send.putExtra(Intent.EXTRA_SUBJECT,"EV Charging Invoice "+inv);
            send.putExtra(Intent.EXTRA_TEXT,"Please find the EV charging invoice attached.");
            send.putExtra(Intent.EXTRA_STREAM,uri); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send,"Share invoice"));
        } catch(Exception ex) {
            Toast.makeText(this,"PDF error: "+ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private void row(Canvas c, Paint p, String left, double amount, int y) {
        p.setTextSize(13); c.drawText(left,40,y,p); c.drawText(money(amount),450,y,p);
    }

    private void stationDialog(TextView stationView) {
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(30,5,30,5);
        EditText name=field("Station / business name",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText gstin=field("GSTIN (optional)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        EditText address=field("Address (optional)",InputType.TYPE_CLASS_TEXT);
        name.setText(prefs.getString("name","EV Charging Station"));
        gstin.setText(prefs.getString("gstin","")); address.setText(prefs.getString("address",""));
        l.addView(name); l.addView(gstin); l.addView(address);
        new android.app.AlertDialog.Builder(this).setTitle("Station Settings").setView(l)
            .setPositiveButton("SAVE",(d,w)->{
                prefs.edit().putString("name",name.getText().toString().trim().isEmpty()?"EV Charging Station":name.getText().toString().trim())
                    .putString("gstin",gstin.getText().toString()).putString("address",address.getText().toString()).apply();
                stationView.setText(prefs.getString("name","EV Charging Station"));
            }).setNegativeButton("CANCEL",null).show();
    }

    private void clearForm() {
        customer.setText(""); phone.setText(""); vehicle.setText(""); kwh.setText("");
        rate.setText("15"); service.setText("0"); parking.setText("0"); gst.setText("18");
        energyAmt.setText("Energy: ₹0.00"); subtotal.setText("Subtotal: ₹0.00");
        gstAmt.setText("GST: ₹0.00"); total.setText("TOTAL: ₹0.00");
    }
}
