# EVChargeBill

**Offline EV charging bill calculator for Android.**

### Included
- Customer and vehicle details
- Energy (kWh) × ₹/kWh calculation
- Service and parking charges
- GST calculation
- Automatic invoice number and date
- Offline PDF invoice generation
- Share invoice to WhatsApp, email, Drive, etc.
- Station/business settings saved locally
- No internet permission
- No server/database dependency
- GitHub Actions workflow that builds an installable debug APK

### Build on GitHub
Open **Actions → Build EVChargeBill APK → Run workflow**.
The generated `app-debug.apk` is available as the workflow artifact.

### Important
This first release is intentionally generic so it can be branded and sold to different EV charging operators. The station name, GSTIN and address are configurable inside the app.
